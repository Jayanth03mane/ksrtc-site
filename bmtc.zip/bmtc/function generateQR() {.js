function generateQR() {
  const name = document.getElementById("pnumber").value;
  const route = document.getElementById("route").value;
  const seat = document.getElementById("seat").value;

  if (!name || !route || !seat) {
    alert("Please fill all fields!");
    return;
  }

  const ticketData = {
    name: pnumbeer,
    route: route,
    seat: seat,
    time: new Date().toLocaleString()
  };

  const qrText = JSON.stringify(ticketData);
  document.getElementById("qr").innerHTML = "";
  new QRCode(document.getElementById("qr"), qrText);
}

function showTicketInfo(decodedText) {
  try {
    const data = JSON.parse(decodedText);
    document.getElementById("ticket-info").innerHTML = `
      <strong>Passenger:</strong> ${data.name}<br/>
      <strong>Route:</strong> ${data.route}<br/>
      <strong>Seat No:</strong> ${data.seat}<br/>
      <strong>Booked At:</strong> ${data.time}
    `;
  } catch (e) {
    document.getElementById("ticket-info").innerText = "Invalid QR Code!";
  }
}

const qrScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
qrScanner.render((decodedText) => {
  showTicketInfo(decodedText);
  qrScanner.clear(); // Stop scanning after one scan
});
function generateTicket() {
  const name = document.getElementById("name").value;
  const from = document.getElementById("from").value;
  const to = document.getElementById("to").value;
  const date = document.getElementById("date").value;
  const seat = document.getElementById("seat").value;
  const bus = document.getElementById("bus").value;

  const ticketData = `
    KSRTC E-Ticket
    Name: ${name}
    From: ${from}
    To: ${to}
    Date: ${date}
    Seat No: ${seat}
    Bus: ${bus}
  `.trim();

  document.getElementById("ticketDetails").innerText = ticketData;
  document.getElementById("ticket").style.display = "block";

  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(ticketData)}`;
  document.getElementById("qrImage").src = qrUrl;
}
